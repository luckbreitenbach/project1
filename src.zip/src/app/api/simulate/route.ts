import { NextResponse } from "next/server";
import { runMonteCarloSimulation, parseCard, Card } from "@/lib/poker-engine";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { heroCards: rawHero, boardCards: rawBoard, opponents: rawOpponents, runs = 10000, potSize = 250, betToCall = 75 } = body;

    const heroCards: [Card, Card] = [
      parseCard(rawHero?.[0] || "As") || { rank: "A", suit: "s", code: "As" },
      parseCard(rawHero?.[1] || "Kh") || { rank: "K", suit: "h", code: "Kh" },
    ];

    const boardCards: Card[] = (rawBoard || [])
      .map((c: string) => parseCard(c))
      .filter((c: Card | null): c is Card => c !== null);

    const opponents = (rawOpponents || []).map((opp: { id: string; name?: string; cards?: string[]; folded?: boolean }) => {
      let cards: [Card, Card] | null = null;
      if (opp.cards && opp.cards.length === 2) {
        const c1 = parseCard(opp.cards[0]);
        const c2 = parseCard(opp.cards[1]);
        if (c1 && c2) cards = [c1, c2];
      }
      return {
        id: opp.id,
        name: opp.name || "Opponent",
        isHero: false,
        cards,
        folded: Boolean(opp.folded),
      };
    });

    const result = runMonteCarloSimulation({
      heroCards,
      boardCards,
      opponents,
      runs: Math.min(50000, Math.max(500, Number(runs) || 5000)),
      potSize: Number(potSize) || 200,
      betToCall: Number(betToCall) || 50,
    });

    return NextResponse.json(result);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Simulation failed";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
