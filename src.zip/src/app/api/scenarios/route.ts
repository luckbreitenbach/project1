import { NextResponse } from "next/server";
import { db } from "@/db";
import { savedScenarios } from "@/db/schema";
import { eq } from "drizzle-orm";
import { INITIAL_SAVED_SCENARIOS } from "@/lib/seed-data";

export async function GET() {
  try {
    const list = await db.select().from(savedScenarios);
    if (list.length === 0) {
      for (const item of INITIAL_SAVED_SCENARIOS) {
        await db.insert(savedScenarios).values(item).onConflictDoNothing();
      }
      const seeded = await db.select().from(savedScenarios);
      return NextResponse.json({ scenarios: seeded });
    }
    return NextResponse.json({ scenarios: list });
  } catch {
    return NextResponse.json({ scenarios: INITIAL_SAVED_SCENARIOS });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const newId = body.id || `scen-${Date.now()}`;
    const newScenario = {
      id: newId,
      userId: body.userId || "user-hero-001",
      title: body.title || "Custom Poker Scenario",
      gameType: body.gameType || "No-Limit Cash $5/$10",
      heroCards: typeof body.heroCards === "string" ? body.heroCards : JSON.stringify(body.heroCards || ["As", "Kh"]),
      boardCards: typeof body.boardCards === "string" ? body.boardCards : JSON.stringify(body.boardCards || []),
      opponentsData: typeof body.opponentsData === "string" ? body.opponentsData : JSON.stringify(body.opponentsData || []),
      potSize: String(body.potSize || "300"),
      betToCall: String(body.betToCall || "80"),
      street: body.street || "flop",
      simulationRuns: Number(body.simulationRuns) || 10000,
      heroEquity: String(body.heroEquity || "50.0"),
      heroWinPct: String(body.heroWinPct || "48.0"),
      heroTiePct: String(body.heroTiePct || "2.0"),
      potOddsPct: String(body.potOddsPct || "21.0"),
      evChips: String(body.evChips || "0"),
      recommendation: body.recommendation || "CALL",
      notes: body.notes || "",
    };

    try {
      await db.insert(savedScenarios).values(newScenario);
    } catch {
      // Fallback
    }

    return NextResponse.json({ scenario: newScenario });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to save scenario";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    try {
      await db.delete(savedScenarios).where(eq(savedScenarios.id, id));
    } catch {
      // Fallback
    }

    return NextResponse.json({ success: true, id });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to delete scenario";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
