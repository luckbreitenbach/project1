import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { INITIAL_DEMO_USER } from "@/lib/seed-data";

export async function GET() {
  try {
    const existing = await db.select().from(users).where(eq(users.id, INITIAL_DEMO_USER.id));
    if (existing.length > 0) {
      return NextResponse.json({ user: existing[0] });
    }
    // Auto insert demo user
    await db.insert(users).values(INITIAL_DEMO_USER).onConflictDoNothing();
    return NextResponse.json({ user: INITIAL_DEMO_USER });
  } catch {
    return NextResponse.json({ user: INITIAL_DEMO_USER });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, name, role, bankroll, preferredTheme, preferredSimRuns, soundEffects } = body;

    const updatedUser = {
      ...INITIAL_DEMO_USER,
      name: name || INITIAL_DEMO_USER.name,
      email: email || INITIAL_DEMO_USER.email,
      role: role || INITIAL_DEMO_USER.role,
      bankroll: Number(bankroll) || INITIAL_DEMO_USER.bankroll,
      preferredTheme: preferredTheme || INITIAL_DEMO_USER.preferredTheme,
      preferredSimRuns: Number(preferredSimRuns) || INITIAL_DEMO_USER.preferredSimRuns,
      soundEffects: soundEffects ?? true,
    };

    try {
      await db.insert(users).values(updatedUser).onConflictDoUpdate({
        target: users.id,
        set: {
          name: updatedUser.name,
          email: updatedUser.email,
          role: updatedUser.role,
          bankroll: updatedUser.bankroll,
          preferredTheme: updatedUser.preferredTheme,
          preferredSimRuns: updatedUser.preferredSimRuns,
          soundEffects: updatedUser.soundEffects,
        }
      });
    } catch {
      // Fallback
    }

    return NextResponse.json({ user: updatedUser });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to update profile";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
