import { NextResponse } from "next/server";
import { db } from "@/db";
import { rangeTemplates } from "@/db/schema";
import { eq } from "drizzle-orm";
import { PRESET_RANGES } from "@/lib/poker-engine";

export async function GET() {
  try {
    const list = await db.select().from(rangeTemplates);
    if (list.length === 0) {
      // Seed default presets
      for (const [key, preset] of Object.entries(PRESET_RANGES)) {
        await db.insert(rangeTemplates).values({
          id: `preset-${key.toLowerCase()}`,
          userId: "user-hero-001",
          name: preset.label,
          category: key.includes("UTG") ? "Preflop Open" : key.includes("BTN") ? "Steal / Positional" : "Exploitative",
          selectedHands: JSON.stringify(preset.hands),
          comboCount: Object.keys(preset.hands).length * 4,
          rangePercentage: "18.5",
        }).onConflictDoNothing();
      }
      const seeded = await db.select().from(rangeTemplates);
      return NextResponse.json({ ranges: seeded });
    }
    return NextResponse.json({ ranges: list });
  } catch {
    return NextResponse.json({ ranges: [] });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const newId = body.id || `range-${Date.now()}`;
    const newRange = {
      id: newId,
      userId: body.userId || "user-hero-001",
      name: body.name || "Custom Range",
      category: body.category || "Custom",
      selectedHands: typeof body.selectedHands === "string" ? body.selectedHands : JSON.stringify(body.selectedHands || {}),
      comboCount: Number(body.comboCount) || 120,
      rangePercentage: String(body.rangePercentage || "15.0"),
    };

    try {
      await db.insert(rangeTemplates).values(newRange);
    } catch {
      // Fallback
    }

    return NextResponse.json({ range: newRange });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to save range";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    try {
      await db.delete(rangeTemplates).where(eq(rangeTemplates.id, id));
    } catch {
      // Fallback
    }

    return NextResponse.json({ success: true, id });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to delete range";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
