import { NextResponse } from "next/server";
import { db } from "@/db";
import { opponentProfiles } from "@/db/schema";
import { eq } from "drizzle-orm";
import { INITIAL_OPPONENTS } from "@/lib/seed-data";

export async function GET() {
  try {
    const list = await db.select().from(opponentProfiles);
    if (list.length === 0) {
      // Seed initial opponent profiles
      for (const opp of INITIAL_OPPONENTS) {
        await db.insert(opponentProfiles).values(opp).onConflictDoNothing();
      }
      const seeded = await db.select().from(opponentProfiles);
      return NextResponse.json({ opponents: seeded });
    }
    return NextResponse.json({ opponents: list });
  } catch {
    return NextResponse.json({ opponents: INITIAL_OPPONENTS });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const newId = body.id || `opp-${Date.now()}`;
    const newOpp = {
      id: newId,
      userId: body.userId || "user-hero-001",
      name: body.name || "Unknown Player",
      avatar: body.avatar || `https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80`,
      archetype: body.archetype || "TAG",
      vpip: String(body.vpip || "24.0"),
      pfr: String(body.pfr || "18.0"),
      threeBet: String(body.threeBet || "7.5"),
      aggressionFactor: String(body.aggressionFactor || "2.5"),
      foldToCbet: String(body.foldToCbet || "45.0"),
      wtsd: String(body.wtsd || "27.0"),
      notes: body.notes || "",
      exploits: typeof body.exploits === "string" ? body.exploits : JSON.stringify(body.exploits || []),
      colorTag: body.colorTag || "emerald",
      handsTracked: Number(body.handsTracked) || 100,
    };

    try {
      await db.insert(opponentProfiles).values(newOpp);
    } catch {
      // Fallback
    }

    return NextResponse.json({ opponent: newOpp });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to create opponent";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    if (!body.id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    const updated = {
      name: body.name,
      archetype: body.archetype,
      vpip: String(body.vpip),
      pfr: String(body.pfr),
      threeBet: String(body.threeBet),
      aggressionFactor: String(body.aggressionFactor),
      foldToCbet: String(body.foldToCbet),
      wtsd: String(body.wtsd),
      notes: body.notes,
      exploits: typeof body.exploits === "string" ? body.exploits : JSON.stringify(body.exploits || []),
      colorTag: body.colorTag,
      handsTracked: Number(body.handsTracked),
    };

    try {
      await db.update(opponentProfiles).set(updated).where(eq(opponentProfiles.id, body.id));
    } catch {
      // Fallback
    }

    return NextResponse.json({ opponent: { id: body.id, ...updated } });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to update opponent";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ error: "ID required" }, { status: 400 });

    try {
      await db.delete(opponentProfiles).where(eq(opponentProfiles.id, id));
    } catch {
      // Fallback
    }

    return NextResponse.json({ success: true, id });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : "Failed to delete opponent";
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
